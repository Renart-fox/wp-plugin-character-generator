<?php

namespace MIEL\CharacterGenerator\Inc\Rest;

function get_saved_characters(){
    global $wpdb;

    $results = $wpdb->get_results("
			Select wp_cg_characters.id AS ID, wp_cg_characters.cg_name AS Personnage, wp_cg_systems.cg_name AS Systeme FROM wp_cg_characters_systems
			JOIN wp_cg_characters on wp_cg_characters_systems.characterId = wp_cg_characters.id
			JOIN wp_cg_systems on wp_cg_characters_systems.systemId = wp_cg_systems.id;
	");
    
    return $results;
}

function get_systems(){
    global $wpdb;

    $results = $wpdb->get_results("
			SELECT wp_cg_systems.id AS ID, wp_cg_systems.cg_name AS Systeme FROM wp_cg_systems;
	");
    
    return $results;
}

function save($request){
    global $wpdb;

    $params = $request->get_json_params();
    $name = $params['name'];
    $cg_obj = json_encode($params['cg_obj']);
    $system = $params['system'];
    
    $wpdb->insert('wp_cg_characters', array ('cg_name' => $name, 'cg_obj' => $cg_obj));
    $wpdb->insert('wp_cg_characters_systems', array ('characterId' => $wpdb->insert_id, 'systemId' => $system));

    return $params;
}