const { Component, render } = wp.element;
import { useState } from 'react';
import { QueryClient, QueryClientProvider, useMutation } from '@tanstack/react-query';

import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Alert from '@mui/material/Alert';
import axios from 'axios';

const queryClient = new QueryClient();

console.log(wp);

const Generator = () => {
    const [snackState, setSnackState] = useState({
        open: false,
        vertical: 'bottom',
        horizontal: 'right',
        message: 'Le personnage a bien été sauvegardé',
        alert: 'success'
    });

    const [characterState, setCharacterState] = useState({
        system: 1,
        name: "",
        cg_obj: {}
    })

    const { vertical, horizontal, open } = snackState;


    const handleSnackClose = (event, reason) => {
        setSnackState({ ...snackState, open: false })
    };

    const snackAction = (
        <>
            <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={handleSnackClose}
            >
                <CloseIcon fontSize="small" />
            </IconButton>
        </>
    );

    const systems = [
        {
            value: 1,
            label: 'D&D 5e',
        },
        {
            value: '2',
            label: 'Vampire : La Mascarade',
        },
        {
            value: '3',
            label: 'Cyberpunk RED',
        },
    ];

    const postCharacterInfo = async () => {
        return await axios.post('/wordpress/wp-json/cg/v1/Save', JSON.stringify(characterState));
    }

    var mutation = useMutation({
        mutationFn: () => {
            return axios.post('/wordpress/wp-json/cg/v1/Save', JSON.stringify(characterState), {
                headers: {
                    "Content-Type": "application/json; charset= UTF-8",
                    'X-WP-Nonce': window.wpnonce
                }
            })
        },
        onError: () => { setSnackState({ ...snackState, open: true, message: 'Erreur dans l\'enregistrement du personnage. Contactez Miel', alert: 'error' }) },
        onSuccess: () => { setSnackState({ ...snackState, open: true, message: 'Le personnage a bien été sauvegardé', alert: 'success' }) }
    })

    return (
        <>
            <Box
                sx={{
                    '& > :not(style)': { m: 2, width: '50ch' },
                }}
                noValidate
                autoComplete="off">
                <TextField id="cg-data-characterName" label="Nom du personnage" variant="standard" type="" onChange={(e) => { setCharacterState({ ...characterState, name: e.target.value }) }} />
                <TextField
                    id="cg-data-system"
                    select
                    label="Système"
                    defaultValue={1}
                    value={characterState.system}
                    onChange={(e) => { setCharacterState({ ...characterState, system: e.target.value }) }}
                >
                    {systems.map((option) => (
                        <MenuItem key={option.value} value={option.value}>
                            {option.label}
                        </MenuItem>
                    ))}
                </TextField>
                <br />
                <Button variant="contained" onClick={() => { mutation.mutate() }}>Sauvegarder</Button>
            </Box >

            <Snackbar
                open={snackState.open}
                autoHideDuration={5000}
                onClose={handleSnackClose}
                message={snackState.message}
                action={snackAction}
                anchorOrigin={{ vertical, horizontal }}
            >
                <Alert
                    onClose={handleSnackClose}
                    severity={snackState.alert}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackState.message}
                </Alert>
            </Snackbar>
        </>
    );
}

function GeneratorComponent() {
    return (
        <QueryClientProvider client={queryClient}>
            <Generator />
        </QueryClientProvider>
    );
}

render(
    <GeneratorComponent />,
    document.getElementById('cg-generator')
);