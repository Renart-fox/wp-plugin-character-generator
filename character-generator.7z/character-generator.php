<?php
/**
 * Plugin Name:       Character Generator
 * Description:       Permet de générer des PNJs
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            Miel :3
 * Author URI:		  https://pa1.aminoapps.com/6722/ba51c68395b64aebd00f4d6b2a75daa06a73e0a4_hq.gif
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       character-generator
 *
 * @package           create-block
 */

 namespace MIEL\CharacterGenerator;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
/*function character_generator_character_generator_block_init() {
	register_block_type( __DIR__ . '/build' );
}
add_action( 'init', 'character_generator_character_generator_block_init' );*/

include('inc/admin/handle_admin_menus.php');
include('inc/rest/api.php');

function character_generator_init() {

	wp_learn_create_database_tables();

	$admin_menus = new Inc\Admin\GenerateMenus();

	add_action('rest_api_init', function() {
		register_rest_route('cg/v1', 'SavedCharacters', array(
			'methods' => 'GET',
			'callback' => 'MIEL\CharacterGenerator\Inc\Rest\get_saved_characters'
		));
		register_rest_route('cg/v1', 'Systems', array(
			'methods' => 'GET',
			'callback' => 'MIEL\CharacterGenerator\Inc\Rest\get_systems'
		));
		register_rest_route('cg/v1', 'Save', array(
			'methods' => 'POST',
			'callback' => 'MIEL\CharacterGenerator\Inc\Rest\save'
		));
	});
}

function wp_learn_create_database_tables() {
    global $wpdb;

    $characters = $wpdb->prefix . 'cg_characters';
    $systems = $wpdb->prefix . 'cg_systems';
    $characters_systems = $wpdb->prefix . 'cg_characters_systems';

    $charset_collate = $wpdb->get_charset_collate();

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$sql = "CREATE TABLE IF NOT EXISTS $characters (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        cg_name VARCHAR(100) NOT NULL,
		cg_obj JSON NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

	dbDelta( $sql );

	$sql = "CREATE TABLE IF NOT EXISTS $systems (
		id mediumint(9) NOT NULL,
		cg_name VARCHAR(100) NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	dbDelta( $sql );

	$wpdb->query("INSERT IGNORE INTO $systems VALUES
		(1, 'dd5e'),
		(2, 'cpred'),
		(3, 'v5e')
	;");

    $sql = "CREATE TABLE IF NOT EXISTS $characters_systems (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        characterId int NOT NULL,
		systemId int NOT NULL,
        PRIMARY KEY  (id),
		INDEX(systemId),
		FOREIGN KEY (characterId)
		REFERENCES $characters(id),

		FOREIGN KEY (systemId)
		REFERENCES $systems(id)
    ) $charset_collate;";
    
    dbDelta( $sql );
}

add_action( 'init', __NAMESPACE__ . '\character_generator_init' );
